angular.module('myApp',['ngRoute'  ])
.config(function($routeProvider, $locationProvider){ 
	$routeProvider
		.when('/',
		{
			templateUrl: 'main.html' 
		})
		.when('/second', {
            templateUrl: 'second.html' 
        })  
        .otherwise({
            redirectTo: '/'
        });
});