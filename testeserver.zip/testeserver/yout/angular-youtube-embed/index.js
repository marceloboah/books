require('./src/angular-youtube-embed');
module.exports = 'youtube-embed';
